import os


class Config:
    LEVEL_NAME = str(os.environ.get("LOG_LEVEL", "INFO")).upper()
    SERVICE_NAME = os.environ.get("SERVICE_NAME", "webhook-handler")
    aws_region = os.environ.get("AWS_REGION", "eu-west-2")
    aws_profile_name = os.environ.get("AWS_PROFILE_NAME") or "hmpps-token"
    aws_role_arn = os.environ.get(
        "AWS_ROLE_ARN") or "arn:aws:iam::563502482979:role/terraform"
    source_id = os.environ.get("EVENT_BUS_SOURCE_ID", "eng.ci.webhooks")
    github_token = os.environ.get("GITHUB_SSM_PARAM", None)
