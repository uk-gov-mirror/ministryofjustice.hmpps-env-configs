import botocore
from project.clients.boto import dynamodb_client
from project.config import Config


class DynamoDB_Handler():
    def __init__(self):
        self.table_name = Config.table_name
        self.client = dynamodb_client()

    def create_table(self):
        try:
            response = self.client.create_table(
                TableName=self.table_name,
                AttributeDefinitions=[
                    {
                        "AttributeName": "PipelineId",
                        "AttributeType": "S"
                    }
                ],
                KeySchema=[
                    {
                        "AttributeName": "PipelineId",
                        "KeyType": "HASH"
                    }
                ],
                ProvisionedThroughput={
                    "ReadCapacityUnits": 10,
                    "WriteCapacityUnits": 10
                }
            )
            print(response)
            return response
        except self.client.exceptions.ResourceInUseException:
            print("Table already exists")
            pass
        return None
