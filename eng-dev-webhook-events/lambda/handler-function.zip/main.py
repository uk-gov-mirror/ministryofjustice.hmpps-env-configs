import json

from project.handlers.codepipeline_handler import CodePipeline_Handler
from project import log


def lambda_handler(event, context):
    MISSING_DATA = True
    branch_name = None
    ACTION_TYPE = None
    pipeline_name = None

    payload = event
    log.info({"message": "Payload recieved", "data": payload})

    if "action" in payload:
        ACTION_TYPE = payload["action"]
        MISSING_DATA = False

    if "branch" in payload:
        branch_name = payload["branch"]
        MISSING_DATA = False

    if "pipeline_name" in payload:
        pipeline_name = payload["pipeline_name"]
        MISSING_DATA = False

    if MISSING_DATA:
        responseObject = {
            "message": "Missing required keys",
            "keys": ["action", "branch", "pipeline_name"],
            "status_code": 500
        }
        return responseObject

    response = "No task completed"

    codepipeline_handler = CodePipeline_Handler(pipeline_name, branch_name)

    if ACTION_TYPE == "push":
        response = codepipeline_handler.start_pipeline()
        log.info({"message": f"action is set to {ACTION_TYPE}"})

    if ACTION_TYPE == "delete":
        response = codepipeline_handler.get_pipeline()
        log.info({"message": f"action is set to {ACTION_TYPE}"})

    if ACTION_TYPE == "create":
        response = codepipeline_handler.create_pipeline()
        log.info({"message": f"action is set to {ACTION_TYPE}"})

    responseObject = {}
    responseObject["statusCode"] = 200
    responseObject["body"] = response
    responseObject["message"] = "Function invoked"
    return json.dumps(responseObject)


if __name__ == "__main__":
    lambda_handler(event={}, context={})
