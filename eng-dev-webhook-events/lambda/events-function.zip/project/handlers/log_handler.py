from logging.config import dictConfig

import structlog

from project.config import Config

dictConfig(
    {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "json": {
                "format": "%(message)s",
                "class": "pythonjsonlogger.jsonlogger.JsonFormatter",
            }
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "json",
            }
        },
        "root": {"level": Config.LEVEL_NAME, "handlers": ["console"]},
    }
)

# The processor list
processors = [
    structlog.stdlib.filter_by_level,  # First step, filter by level to
    structlog.stdlib.add_logger_name,  # module name
    structlog.stdlib.add_log_level,  # log level
    structlog.stdlib.PositionalArgumentsFormatter(),  # % formatting
    structlog.processors.StackInfoRenderer(),  # adds stack if stack_info=True
    structlog.processors.format_exc_info,  # Formats exc_info
    structlog.processors.UnicodeDecoder(),  # Decodes all bytes in dict to unicode
    # Because timestamps! UTC by default
    structlog.processors.TimeStamper("iso"),
    structlog.stdlib.render_to_log_kwargs,  # Preps for logging call
]


def log_handler():
    # Configure structlog
    global processors
    structlog.configure(
        processors=processors,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )
    service_name = Config.SERVICE_NAME
    log_level = Config.LEVEL_NAME
    logger = structlog.get_logger(service_name)
    logger.setLevel(log_level)
    return logger
