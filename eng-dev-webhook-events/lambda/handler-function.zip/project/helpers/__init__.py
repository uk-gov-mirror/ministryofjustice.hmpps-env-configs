from project.clients.boto import ssm_client
from project import log
from slugify import slugify


def ssm_get_parameter(parameter_name: str):
    log.info({"message": f"Attempting to retrieve ssm parameter {parameter_name}"})
    client = ssm_client()
    response = client.get_parameter(
        Name=parameter_name,
        WithDecryption=True
    )
    if "Parameter" in response:
        return response["Parameter"]["Value"]
    return None


def create_slug(slug_string: str):
    slug = slugify(slug_string)
    log.info({"message": f"Create slug string {slug}"})
    return str(slug_string)
