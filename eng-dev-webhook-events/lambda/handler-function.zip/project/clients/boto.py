import boto3
from boto3 import client

from project.config import Config


def codepipeline_client():
    client = boto3.client(
        "codepipeline",
        region_name=Config.aws_region
    )

    return client


def ssm_client():
    client = boto3.client(
        'ssm',
        region_name=Config.aws_region
    )
    return client
