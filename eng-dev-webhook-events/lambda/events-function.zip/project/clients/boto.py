import boto3
from boto3 import client

from project.config import Config


def dynamodb_client():
    client = boto3.client(
        "dynamodb",
        region_name=Config.aws_region
    )

    return client


def event_bridge_client():
    client = boto3.client(
        "events",
        region_name=Config.aws_region
    )

    return client
