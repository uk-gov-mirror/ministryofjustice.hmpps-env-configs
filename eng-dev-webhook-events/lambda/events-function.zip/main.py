import json

from project.handlers.event_bridge_handler import EventBridge_Handler
from project import log


def lambda_handler(event, context):
    branch_name = None
    ACTION_TYPE = None
    task_payload = None

    responseObject = {}
    responseObject["statusCode"] = 200
    responseObject["headers"] = {}
    responseObject["headers"]["Content-Type"] = "application/json"
    responseObject["message"] = "Function invoked"

    request_headers = event["header"]
    log.info({"message": "request headers recieved", "headers": request_headers})
    payload = event["body"]
    branch_name = str(payload["ref"])

    if "refs/tags" in branch_name:
        responseObject["message"] = f'{responseObject["message"]}, tag push events currently ignored.'
        return json.dumps(responseObject)

    if request_headers["X-GitHub-Event"] == "push":
        branch_name = branch_name.replace("refs/heads/", "")
        ACTION_TYPE = request_headers["X-GitHub-Event"]

    if request_headers["X-GitHub-Event"] == "delete":
        ACTION_TYPE = request_headers["X-GitHub-Event"]

    if request_headers["X-GitHub-Event"] == "create":
        ACTION_TYPE = request_headers["X-GitHub-Event"]

    if branch_name is not None:
        log.info({"message": f"payload branch {branch_name}"})

    if ACTION_TYPE is not None:
        event_handler = EventBridge_Handler()
        task_payload = {
            "action": ACTION_TYPE,
            "source_branch": branch_name,
            "message": "task payload",
            "repository": payload["repository"]["name"],
            "resource_arn": context.invoked_function_arn
        }
        log.info(task_payload)
        response = event_handler.put_event(
            payload=task_payload)
        log.info({"message": "Webhook event sent"})

    return json.dumps(responseObject)


if __name__ == "__main__":
    lambda_handler(event={}, context={})
