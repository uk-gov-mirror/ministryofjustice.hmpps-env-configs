import botocore
import json
import datetime
from project.clients.boto import codepipeline_client
from project.helpers import ssm_get_parameter, create_slug
from project.config import Config
from project import log


class CodePipeline_Handler():
    def __init__(self, pipeline_name: str, branch_name: str):
        self.client = codepipeline_client()
        self.pipeline_name = pipeline_name
        self.branch_name = branch_name
        self.target_pipeline_name = create_slug(
            f"{pipeline_name}_{branch_name}"
        )

    def get_pipeline(self):
        log.info({"message": f"Getting details for pipeline {self.pipeline_name}"})
        response = self.client.get_pipeline(
            name=self.pipeline_name
        )
        pipeline_details = response["pipeline"]
        del pipeline_details["version"]
        pipeline_details
        return pipeline_details

    def create_pipeline(self):
        log.info({"message": f"Creating a duplicate for {self.pipeline_name}"})
        pipeline_details = self.get_pipeline(self.pipeline_name)
        log.info({"message": pipeline_details})
        pipeline_details["name"] = self.target_pipeline_name
        pipeline_details["stages"][0]["actions"][0]["configuration"]["Branch"] = self.branch_name
        pipeline_details["stages"][0]["actions"][0]["configuration"]["PollForSourceChanges"] = "false"
        oauth_token = ssm_get_parameter(Config.github_token)
        pipeline_details["stages"][0]["actions"][0]["configuration"]["OAuthToken"] = oauth_token
        response = self.client.create_pipeline(pipeline=pipeline_details)
        log.info({"message": "pipeline creation result",
                  "data": response})
        return response

    def start_pipeline(self):
        log.info(
            {"message": f"Starting build pipeline for {self.target_pipeline_name}"})
        return {}
