import botocore
import json
import datetime
from project.clients.boto import event_bridge_client
from project.config import Config
from project import log


class EventBridge_Handler():
    def __init__(self):
        self.client = event_bridge_client()
        self.event_bus_name = "default"
        self.source_id = Config.source_id

    def put_event(self, payload={}):
        response = self.client.put_events(
            Entries=[
                {
                    "Time": datetime.datetime.now(),
                    "Source": self.source_id,
                    "DetailType": payload["action"],
                    "Detail": json.dumps(payload),
                    'EventBusName': self.event_bus_name,
                    "Resources": [payload["resource_arn"]]
                },
            ]
        )
        log.info({"message": "Put event task complete", "body": response})
        return response
